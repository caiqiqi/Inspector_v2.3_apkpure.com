package android.support.v4.view;

import android.view.View;

public interface ViewPropertyAnimatorUpdateListener {
    void onAnimationUpdate(View view);
}
