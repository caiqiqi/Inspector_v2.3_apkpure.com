package com.google.android.gms.ads.mediation;

@Deprecated
public interface NetworkExtras {
}
