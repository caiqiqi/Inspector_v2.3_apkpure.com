package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.internal.af.a;
import com.google.android.gms.drive.realtime.internal.m;

public class c extends a {
    public void a(OnContentsResponse onContentsResponse) throws RemoteException {
    }

    public void a(OnDeviceUsagePreferenceResponse onDeviceUsagePreferenceResponse) throws RemoteException {
    }

    public void a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
    }

    public void a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
    }

    public void a(OnDrivePreferencesResponse onDrivePreferencesResponse) throws RemoteException {
    }

    public void a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
    }

    public void a(OnListParentsResponse onListParentsResponse) throws RemoteException {
    }

    public void a(OnLoadRealtimeResponse onLoadRealtimeResponse, m mVar) throws RemoteException {
    }

    public void a(OnMetadataResponse onMetadataResponse) throws RemoteException {
    }

    public void a(OnResourceIdSetResponse onResourceIdSetResponse) throws RemoteException {
    }

    public void a(OnStorageStatsResponse onStorageStatsResponse) throws RemoteException {
    }

    public void a(OnSyncMoreResponse onSyncMoreResponse) throws RemoteException {
    }

    public void n(Status status) throws RemoteException {
    }

    public void onSuccess() throws RemoteException {
    }
}
