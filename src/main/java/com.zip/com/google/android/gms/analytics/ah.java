package com.google.android.gms.analytics;

interface ah {
    boolean fe();
}
