package com.google.android.gms.ads.mediation.customevent;

public interface CustomEvent {
    void onDestroy();

    void onPause();

    void onResume();
}
