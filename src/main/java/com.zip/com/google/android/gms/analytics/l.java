package com.google.android.gms.analytics;

public enum l {
    NONE,
    GZIP
}
