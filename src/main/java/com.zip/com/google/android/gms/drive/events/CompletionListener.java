package com.google.android.gms.drive.events;

public interface CompletionListener extends c {
    void onCompletion(CompletionEvent completionEvent);
}
