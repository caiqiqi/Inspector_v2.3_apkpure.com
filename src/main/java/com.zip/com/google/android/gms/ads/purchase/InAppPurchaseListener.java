package com.google.android.gms.ads.purchase;

public interface InAppPurchaseListener {
    void onInAppPurchaseRequested(InAppPurchase inAppPurchase);
}
