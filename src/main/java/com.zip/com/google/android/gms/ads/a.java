package com.google.android.gms.ads;

public final class a {
    public static AdSize a(int i, int i2, String str) {
        return new AdSize(i, i2, str);
    }
}
