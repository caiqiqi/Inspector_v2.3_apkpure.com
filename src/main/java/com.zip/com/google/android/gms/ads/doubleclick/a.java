package com.google.android.gms.ads.doubleclick;

public interface a {
}
