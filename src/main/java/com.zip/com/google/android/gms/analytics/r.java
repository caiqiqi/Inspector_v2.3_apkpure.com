package com.google.android.gms.analytics;

import java.util.List;

public interface r {
    int a(List<ab> list, af afVar, boolean z);

    void ad(String str);

    boolean ea();

    void setDryRun(boolean z);
}
