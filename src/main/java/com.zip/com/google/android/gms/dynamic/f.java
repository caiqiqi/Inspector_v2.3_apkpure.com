package com.google.android.gms.dynamic;

public interface f<T extends LifecycleDelegate> {
    void a(T t);
}
