package com.google.ads.mediation.customevent;

@Deprecated
public interface CustomEventInterstitialListener extends CustomEventListener {
    void onReceivedAd();
}
