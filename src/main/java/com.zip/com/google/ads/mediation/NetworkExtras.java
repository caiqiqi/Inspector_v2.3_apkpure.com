package com.google.ads.mediation;

@Deprecated
public interface NetworkExtras extends com.google.android.gms.ads.mediation.NetworkExtras {
}
